package com.mycompany.myapp.domain.enumeration;

/**
 * The AuthenticationType enumeration.
 */
public enum AuthenticationType {
    EMAIL,
    MOBILE,
}
