package com.mycompany.myapp.domain.enumeration;

/**
 * The SpacedRepetition enumeration.
 */
public enum SpacedRepetition {
    REPEAT_THREE_TIMES,
    REPEAT_FIVE_TIMES,
    REPEAT_SEVEN_TIMES,
}
