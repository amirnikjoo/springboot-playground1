package com.mycompany.myapp.domain.enumeration;

/**
 * The LearningType enumeration.
 */
public enum LearningType {
    TYPE_A,
    TYPE_B,
    TYPE_C,
}
