package com.mycompany.myapp.domain.enumeration;

/**
 * The ConsumerType enumeration.
 */
public enum ConsumerType {
    VISITOR,
    CUSTOMER,
    STUDENT,
    GRADUATED,
}
