package com.mycompany.myapp.domain.enumeration;

/**
 * The CourseIntensity enumeration.
 */
public enum CourseIntensity {
    REGULAR,
    INTENSIVE,
}
