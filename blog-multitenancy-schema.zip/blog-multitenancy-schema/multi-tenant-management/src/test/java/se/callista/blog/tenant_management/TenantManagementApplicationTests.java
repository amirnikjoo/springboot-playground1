package se.callista.blog.tenant_management;

import org.junit.jupiter.api.Test;
import se.callista.blog.tenant_management.annotation.SpringBootIntegrationTest;

@SpringBootIntegrationTest
class TenantManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
