package ir.shaparak.eWallet;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@Data
@NoArgsConstructor
public class AlakiDto {
    Date bDate;


}
