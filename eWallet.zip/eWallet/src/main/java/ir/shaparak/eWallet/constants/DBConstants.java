/*
package ir.shaparak.eWallet.constants;

public class DBConstants {
    public static final Integer VARCHAR_LEN_10 = 10;
    public static final Integer VARCHAR_LEN_16 = 16;
}
*/
