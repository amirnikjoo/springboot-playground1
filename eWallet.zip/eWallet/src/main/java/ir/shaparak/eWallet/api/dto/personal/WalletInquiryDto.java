package ir.shaparak.eWallet.api.dto.personal;

import lombok.Data;

@Data
public class WalletInquiryDto {

    private String stan;

    private String originalReferenceNumber;

    private String originalStan;

}
