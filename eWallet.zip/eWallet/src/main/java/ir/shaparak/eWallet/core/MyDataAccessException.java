/*
package ir.shaparak.eWallet.core;

public class MyDataAccessException extends IRuntimeException {
    Throwable cause;

    public MyDataAccessException(Throwable cause, Integer sourceId) {
        super(cause, sourceId);
        this.cause = cause;
    }

    public Throwable getException() {
        return cause;
    }
}*/
