package ir.shaparak.eWallet.api.dto.personal;

public enum IdentifierType {
    REAL_PERSON,
    CORPORATE_PERSON,
    FOREIGN_REAL_PERSON
}