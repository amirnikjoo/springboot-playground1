package ir.shaparak.eWallet.api.dto.personal;

import lombok.Data;

@Data
public class WalletChangeMobileNoDto {

    private String walletId;

    private String stan;

    private String mobileNumber;

}
